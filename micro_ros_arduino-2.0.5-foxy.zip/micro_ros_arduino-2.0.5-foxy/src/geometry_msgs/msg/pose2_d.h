// generated from rosidl_generator_c/resource/idl.h.em
// with input from geometry_msgs:msg/Pose2D.idl
// generated code does not contain a copyright notice

#ifndef GEOMETRY_MSGS__MSG__POSE2_D_H_
#define GEOMETRY_MSGS__MSG__POSE2_D_H_

#include "geometry_msgs/msg/detail/pose2_d__struct.h"
#include "geometry_msgs/msg/detail/pose2_d__functions.h"
#include "geometry_msgs/msg/detail/pose2_d__type_support.h"

#endif  // GEOMETRY_MSGS__MSG__POSE2_D_H_
